﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HW5
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie myCookies = Request.Cookies["hw5"];
            if(myCookies != null)
            {
                Information.Text = "Welcome back user " + myCookies["emailAddress"];
            }
            else
            {
                Information.Text = "Hi! New user";
            }
        }

        protected void loginButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("Crime.aspx");
        }

        protected void signupButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("Signup.aspx");
        }
    }
}