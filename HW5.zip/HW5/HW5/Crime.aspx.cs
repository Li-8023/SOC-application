﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Caching;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HW5
{
    public partial class Crime : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void submitButton_Click(object sender, EventArgs e)
        {
            String state = stateTextBox.Text;
            int begin = Convert.ToInt32(beginTextBox.Text);
            int end = Convert.ToInt32(endTextBox.Text);
            string url = "http://localhost:61616/Service1.svc/CrimeData?state=" + state + "&begin=" + begin + "&end=" + end;
            
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.ContentType = "application/json";
            WebResponse response = request.GetResponse();
            Stream dataStream = response.GetResponseStream();
            StreamReader sreader = new StreamReader(dataStream);
            string responsereader = sreader.ReadToEnd();

            List<RootObject> crimeObject = JsonConvert.DeserializeObject<List<RootObject>>(responsereader);

            int count = crimeObject.Count();
            int violentResult = 0;
            int robberResult = 0;
            int homicideResult = 0;
            for (int i = 0; i < count; i++)
            {
                violentResult += crimeObject[i].violentCrime;
                robberResult += crimeObject[i].robbery;
                homicideResult += crimeObject[i].homicide;
            }

            
            resultTextBox.Text = "Violent data: " + violentResult.ToString() + "\n" + "Robbery data: " + robberResult.ToString()
                + "\n" + "Homicide data: " + homicideResult.ToString() + "\n";

            int sum = violentResult + robberResult + homicideResult;
            int duration = end - begin;
            double average = sum / duration;

            if (average > 10000)
            {
                result.Text = "This community is dangerous! :( ";
            }
            else
            {
                result.Text = "This community is safe! ^_^ ";
            }

            
        }

        protected void backButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }

        protected void nextButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("School.aspx");
        }

        protected void histroyButton_Click(object sender, EventArgs e)
        {
            //cache
            if (Cache["cachedDataDepend"] == null)
            {
                // Cache["crime"] = stateTextBox.Text;
                
                string s= stateTextBox.Text;
                string begin = beginTextBox.Text;
                string end = endTextBox.Text;
                string final = "State: " + s + "" + " Begin year: " + begin + "" + " End year " + end;
                //    searchHistory.Text = s;
                searchHistory.Text = "State: " + s + "" + " Begin year: " + begin + "" + " End year " + end;
                Cache.Insert("cachedDataDepend", final
                    ,null,
               DateTime.Now.AddSeconds(60), Cache.NoSlidingExpiration);
            }
            else
            {
                /*
                String result = (string)Cache["crime"];
                searchHistory.Text = result;
                */
                searchHistory.Text = Cache["cachedDataDepend"].ToString();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            HttpCookie myCookies = Request.Cookies["hw5"];
            if (myCookies != null)
            {

                stateTextBox.Text = myCookies["state"];
            }
            else
            {

                stateTextBox.Text = "";
            }
        }
    }
}