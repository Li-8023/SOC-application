﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HW5
{
    public partial class Store : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void submitButton_Click(object sender, EventArgs e)
        {
            Double latitude = Convert.ToDouble(latitudeTextBox.Text);
            Double longitude = Convert.ToDouble(longitudeTextBox.Text);

            string url = "http://localhost:61616/Service1.svc/findNeartestStore?latitude=" + latitude+"&longitude="+longitude;

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            WebResponse response = request.GetResponse();
            Stream dataStream = response.GetResponseStream();
            StreamReader sreader = new StreamReader(dataStream);
            string responsereader = sreader.ReadToEnd();
            FindStore storeObject = JsonConvert.DeserializeObject<FindStore>(responsereader);

           
            string[] result = new string[storeObject.results.Count];
            string[] names = new string[storeObject.results.Count];


            for (int i = 0; i < storeObject.results.Count; i++)
            {
                result[i] = storeObject.results[i].vicinity;
            }

            for (int i = 0; i < storeObject.results.Count; i++)
            {
                names[i] = storeObject.results[i].name;
            }

            if (result.Length == 0)
            {
                resultTextBox.Text = "There is no store found";
            }
            else
            {

                for (int i = 0; i < result.Length; i++)
                {
                    resultTextBox.Text += names[i].ToString() + " at " + result[i].ToString() + "\n";
                }

            }

            if(result.Length >= 4)
            {
                result1.Text = "This community is very convenient to live in! :)";
            }
            else
            {
                result1.Text = "This community is not very convenient to live in! :(";
            }
        }

        protected void backButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("School.aspx");
        }

        protected void nextButton_Click(object sender, EventArgs e)
        {
            
            Response.Redirect("Login.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            HttpCookie myCookies = Request.Cookies["hw5"];
            if (myCookies != null)
            {

                latitudeTextBox.Text = myCookies["latitude"];
                longitudeTextBox.Text = myCookies["longitude"];
            }
            else
            {

                latitudeTextBox.Text = "";
                longitudeTextBox.Text = "";
            }
        }
    }
}