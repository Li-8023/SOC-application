﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace HW5
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {
        //Crime service
        [OperationContract]
        [WebGet(UriTemplate = "/CrimeData?state={state}&begin={begin}&end={end}", ResponseFormat = WebMessageFormat.Json)]
        List<RootObject> CrimeData(string state, int begin, int end);

        //find school service
        [OperationContract]
        [WebGet(UriTemplate = "/getSchool?latitude={latitude}&longitude={longitude}", ResponseFormat = WebMessageFormat.Json)]
        FindSchool getSchool(double latitude, double longitude);

        //find nearby library
        [OperationContract]
        [WebGet(UriTemplate = "/getLibrary?latitude={latitude}&longitude={longitude}", ResponseFormat = WebMessageFormat.Json)]
        FindSchool getLibrary(double latitude, double longitude);

        //find nearby store
        [OperationContract]
        [WebGet(UriTemplate = "/findNeartestStore?latitude={latitude}&longitude={longitude}", ResponseFormat = WebMessageFormat.Json)]
        FindStore findNearestStore(double latitude, double longitude);
    }

    public class RootObject
    {
        public int violentCrime { get; set; }

        public int homicide { get; set; }

        public int robbery { get; set; }

    }

    public class FindSchool
    {
        public List<Results> results { get; set; }
    }

    public class Results
    {
        public String name { get; set; }

    }

    public class FindStore
    {
        public String next_page_token { get; set; }
        public List<ResultsStore> results { get; set; }

    }
    public class ResultsStore
    {
        public String name { get; set; }
        public String vicinity { get; set; }
    }

}
