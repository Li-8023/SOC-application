﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HW5
{
    public partial class School : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void submitButton_Click(object sender, EventArgs e)
        {
            Double latitude = Convert.ToDouble(latitudeTextBox.Text);
            Double longitude = Convert.ToDouble(longitudeTextBox.Text);

            string url = "http://localhost:61616/Service1.svc/getSchool?latitude=" + latitude+"&longitude="+longitude;

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            WebResponse response = request.GetResponse();
            Stream dataStream = response.GetResponseStream();
            StreamReader sreader = new StreamReader(dataStream);
            string responsereader = sreader.ReadToEnd();
            FindSchool schoolObject = JsonConvert.DeserializeObject<FindSchool>(responsereader);

            string[] result = new string[schoolObject.results.Count];

            for (int i = 0; i < schoolObject.results.Count; i++)
            {
                result[i] = schoolObject.results[i].name;
            }

            if (result.Length == 0)
            {
                resultTextBox.Text = "There is no school found";
            }
            else
            {
                for (int i = 0; i < result.Length; i++)
                {
                    resultTextBox.Text += result[i].ToString() + "\t";
                }
            }

            if(result.Length >= 3 )
            {
                result2.Text = "This community has excellent educational resources! :)";
            }
            else
            {
                result2.Text = "The educational resources in this community are a bit lacking! :(";
            }
        }

        protected void backButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("Crime.aspx");
        }

        protected void nextButton_Click(object sender, EventArgs e)
        {
            Response.Redirect("Store.aspx");
        }

        protected void libraryButton_Click(object sender, EventArgs e)
        {
            Double latitude = Convert.ToDouble(latitudeTextBox.Text);
            Double longitude = Convert.ToDouble(longitudeTextBox.Text);

            string url = "http://localhost:61616/Service1.svc/getLibrary?latitude=" + latitude + "&longitude=" + longitude;
            //string url = "http://webstrar20.fulton.asu.edu/page5/Service1.svc/getLibrary?latitude=" + latitude + "&longitude=" + longitude;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            WebResponse response = request.GetResponse();
            Stream dataStream = response.GetResponseStream();
            StreamReader sreader = new StreamReader(dataStream);
            string responsereader = sreader.ReadToEnd();
            FindSchool schoolObject = JsonConvert.DeserializeObject<FindSchool>(responsereader);

            string[] result = new string[schoolObject.results.Count];

            for (int i = 0; i < schoolObject.results.Count; i++)
            {
                result[i] = schoolObject.results[i].name;
            }

            if (result.Length == 0)
            {
                libraryTextBox.Text = "There is no library found";
            }
            else
            {
                for (int i = 0; i < result.Length; i++)
                {
                    libraryTextBox.Text += result[i].ToString() + "\t";
                }
            }

            if (result.Length >= 3)
            {
                result3.Text = "This community has a very cultural atmosphere! :)";
            }
            else
            {
                result3.Text = "This community lacks cultural atmosphere! :(";
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            HttpCookie myCookies = Request.Cookies["hw5"];
            if (myCookies != null)
            {

                latitudeTextBox.Text = myCookies["latitude"];
                longitudeTextBox.Text = myCookies["longitude"];
            }
            else
            {

                latitudeTextBox.Text = "";
                longitudeTextBox.Text = "";
            }
        }
    }
}