﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using Newtonsoft.Json;

namespace HW5
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        public List<RootObject> CrimeData(string state, int begin, int end)
        {

            string url = "https://api.usa.gov/crime/fbi/cde/estimate/state/" + state + "?from=" + begin + "&to=" + end + "&API_KEY=fVS3Y2gxPsdgr2IgIslNQlgfHKwK5WPNkCfGktZG";

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            WebResponse response = request.GetResponse();
            Stream dataStream = response.GetResponseStream();
            StreamReader sreader = new StreamReader(dataStream);
            string responsereader = sreader.ReadToEnd();
            response.Close();

            List<RootObject> crimeObject = JsonConvert.DeserializeObject<List<RootObject>>(responsereader);
            return crimeObject;
        }

        public FindSchool getSchool(double latitude, double longitude)
        {

            string url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=" + latitude + "%2C" + longitude + "&radius=1500&type=school&key=AIzaSyBPj-1mPW3RRjFQMe9R_zLpCj3ZV5oy8Es";

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            WebResponse response = request.GetResponse();
            Stream dataStream = response.GetResponseStream();
            StreamReader sreader = new StreamReader(dataStream);
            string responsereader = sreader.ReadToEnd();
            response.Close();

            FindSchool schoolObject = JsonConvert.DeserializeObject<FindSchool>(responsereader);
            return schoolObject;
        }
        public FindSchool getLibrary(double latitude, double longitude)
        {
            string url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=" + latitude + "%2C" + longitude + "&radius=1500&type=library&key=AIzaSyBPj-1mPW3RRjFQMe9R_zLpCj3ZV5oy8Es";

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            WebResponse response = request.GetResponse();
            Stream dataStream = response.GetResponseStream();
            StreamReader sreader = new StreamReader(dataStream);
            string responsereader = sreader.ReadToEnd();
            response.Close();

            FindSchool schoolObject = JsonConvert.DeserializeObject<FindSchool>(responsereader);
            return schoolObject;


        }

        public FindStore findNearestStore(double latitude, double longitude)
        {
            string url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=" + latitude + "," + longitude + "&radius=500&type=store&key=AIzaSyBPj-1mPW3RRjFQMe9R_zLpCj3ZV5oy8Es";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            WebResponse response = request.GetResponse();
            Stream dataStream = response.GetResponseStream();
            StreamReader sreader = new StreamReader(dataStream);
            string responsereader = sreader.ReadToEnd();
            response.Close();

            FindStore storeObject = JsonConvert.DeserializeObject<FindStore>(responsereader);

            return storeObject;


        }


    }
}
