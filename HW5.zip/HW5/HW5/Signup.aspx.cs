﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HW5
{
    public partial class Signup : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void createButton_Click(object sender, EventArgs e)
        {
            HttpCookie myCookies = Request.Cookies["hw5"];
            if(myCookies == null)
            {
                myCookies = new HttpCookie("hw5");
                myCookies.Expires = DateTime.Now.AddMinutes(120);

                myCookies["emailAddress"] = emailTextBox.Text;
                myCookies["password"] = passwordTextBox.Text;
                myCookies["latitude"] = latitudeTextBox.Text;
                myCookies["longitude"] = longitudeTextBox.Text;
                myCookies["state"] = stateTextBox.Text;

                Response.Cookies.Add(myCookies);
                Response.Redirect("Login.aspx");
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
            
        }
    }
}